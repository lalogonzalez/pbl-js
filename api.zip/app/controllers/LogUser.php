<?php

class LogUser extends BaseController {
	
	public function checkuser(){
		$token = Input::get('token');

		//if(Session::has('user'))return CategoriesManager::getCategories($user->id);

		$users = User::where('id','>',0)->get()->lists('id','cuenta');

		if(isset($users[$token])){
			$user = User::find($users[$token]);

			Session::put('user',$user);

			return CategoriesManager::getCategories($users[$token]);
		}
		else {
			LogUser::signUp($token);
		}
	}

	public function signUp($token){
		$user = new User;
		$user->cuenta = $token;
		$user->save();

		Session::put('user',$user);

		return CategoriesManager::setCategories($user);
	}

}
