<?php

class ProcessLocation extends BaseController {
	
	public function process(){
		$token = Input::get("token");
		$lon = Input::get("lon");
		$lat = Input::get("lat");

		//location=25.6490816,-100.2898284
		//&opennow=true

		$url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=".$lat.",".$lon."&radius=1000&key=AIzaSyB90eLH7kDZI_N3HDxCIc5-UzgPCMsCahs&types=";

		$user = Session::get('user');
		$categories = UserCategories::where('usuario', $user->id)->where('status', 1)->get();

		foreach ($categories as $category) {
			$cat = Categories::find($category->id);
			$url .= $cat->name."|";
		}

		$url .= "food";

		$data = ProcessLocation::getURLContent($url);
		$data = json_decode($data);
		$results = $data->results;
		
		//7echo $url;

		//print_r($results);

		$i = 0;
		$mayor = 0;
		$lon *= 111;
		$lat *= 111;
		foreach ($results as $key => $location) {
			$geo = $location->geometry->location;
			$geo->lng *= 111;
			$geo->lat *= 111;
			$dist = pow($lon + $geo->lng, 2) +  pow($lat + $geo->lat, 2);
			$dist = pow($dist, .5);

			
			//	echo $dist."<br>";

			$value = 100 - $dist;
			/*$value += ( numero de aceptaciones (might be negative)  x 8  0);
			$value += ( categorias que coinciden x 15  0);*/
			if ($value > $mayor ) {
				$i = $key;
				$mayor = $value;
			}
		}

		echo json_encode($results[$i]);

		return "";

	}

	static function getURLContent($url){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		$data = curl_exec($curl);
		curl_close($curl);

		return $data; 
	}

}
