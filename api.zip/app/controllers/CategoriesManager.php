<?php

class CategoriesManager extends BaseController {
	
	public static function setCategories($user){
		$categories = Categories::all();

		foreach ($categories as $cat) {
			$usr_cat['categoria'] = $cat->id;
			$usr_cat['usuario'] = $user->id;
			$usr_cat['status'] = 0;
			
			$user_categories[] = $usr_cat;
		}

		DB::table('usuario-cat')->insert($user_categories);

		return CategoriesManager::getCategories($user->id);
	}

	public static function getCategories($user){
		$categories = Categories::all();

		$usr_cat = UserCategories::where("usuario","=",$user)->get()->lists('status','categoria');

		foreach ($categories as $cat) {
			$cats['nombre'] = $cat->nombre;
			$cats['sub'] = $cat->subtitulo;
			$cats['status'] = $usr_cat[$cat->id];
			$data[] = $cats;
		}

		echo json_encode($data);

		return "";
	}

	public function changeStatus(){
		$id = Input::get('id');
		
	}

}
