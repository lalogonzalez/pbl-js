<?php

class UserCategories extends Eloquent {

	protected $table = 'usuario-cat';

}