<?php

class Locations extends Eloquent {

	protected $table = 'ubicaciones';

}